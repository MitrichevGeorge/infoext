document.addEventListener("DOMContentLoaded", () => {
  const userEl = document.getElementById("user");
  const taskEl = document.getElementById("task");
  const codeEl = document.getElementById("code");
  const downloadBtn = document.getElementById("downloadBtn");
  const copyBtn = document.getElementById("copyBtn");

  const browserAPI = typeof browser !== "undefined" ? browser : chrome;

  let generatedScript = "";
  let chapterId = "unknown";

  function highlightPython(code) {
    return code
      .replace(/#.*/g, match => `<span class="comment">${match}</span>`)
      .replace(/".*?"/g, match => `<span class="string">${match}</span>`)
      .replace(/'.*?'/g, match => `<span class="string">${match}</span>`)
      .replace(/\b(def|if|else|elif|for|while|in|return|import|from|class|try|except|with|as|True|False|None)\b/g, 
               match => `<span class="keyword">${match}</span>`);
  }

  browserAPI.tabs.query({ active: true, currentWindow: true }, tabs => {
    const url = tabs[0].url || "";
    if (!url.includes("informatics.msk.ru")) {
      userEl.textContent = "Не на informatics.msk.ru";
      taskEl.textContent = "откройте задачу";
      codeEl.textContent = "Перейдите на страницу задачи на informatics.msk.ru";
      return;
    }

    browserAPI.cookies.getAll({ url: "https://informatics.msk.ru" }, cookies => {
      const c = {};
      cookies.forEach(k => c[k.name] = k.value);

      browserAPI.tabs.executeScript(tabs[0].id, {
        code: `JSON.stringify([
          document.querySelector('.userbutton .usertext')?.textContent.trim() || "Аноним",
          document.querySelector('h2')?.textContent.trim() || "Задача",
          new URLSearchParams(location.search).get('chapterid') || "0"
        ])`
      }, result => {
        if (!result || !result[0]) {
          codeEl.textContent = "Не удалось получить данные задачи";
          return;
        }

        const [name, title, chapterid] = JSON.parse(result[0]);
        chapterId = chapterid;

        userEl.textContent = name;
        taskEl.textContent = `${chapterid} — ${title}`;

        generatedScript = generateScript(c, chapterid, title);
        codeEl.innerHTML = highlightPython(generatedScript.replace(/</g, "&lt;").replace(/>/g, "&gt;"));

        // Кнопки
        downloadBtn.onclick = () => {
          const blob = new Blob([generatedScript], { type: "text/x-python" });
          const url = URL.createObjectURL(blob);
          browserAPI.downloads.download({
            url: url,
            filename: `autosubmit_${chapterid}.py`,
            saveAs: true
          });
          setTimeout(() => URL.revokeObjectURL(url), 5000);
        };

        copyBtn.onclick = () => {
          navigator.clipboard.writeText(generatedScript).then(() => {
            copyBtn.textContent = "Скопировано!";
            copyBtn.classList.add("copied");
            setTimeout(() => {
              copyBtn.textContent = "Скопировать в буфер";
              copyBtn.classList.remove("copied");
            }, 2000);
          });
        };
      });
    });
  });
});

// Тот же generateScript, что и раньше (можно оставить без изменений)
function generateScript(cookies, problemId, taskName) {
  return `# Автоматически сгенерировано расширением "Informatics Auto-Submit Pro"
# Задача №${problemId}: ${taskName}
# Запусти и перетащи свой .py файл в терминал

import requests, time, random
from pathlib import Path

COOKIES = {
    "cf_clearance": "${cookies.cf_clearance || ""}",
    "MoodleSession": "${cookies.MoodleSession || ""}",
    "MOODLEID1_": "${cookies.MOODLEID1_ || ""}"
}

PROBLEM_ID = ${problemId}
LANG_ID = 27
COURSE_ID = 6325
SUBMIT_URL = f"https://informatics.msk.ru/py/problem/{PROBLEM_ID}/submit"

TRASH = ["# kek", "# lol", "# spam", "# auto", "# pls_accept", "# generated", "# cheburek", "# 100%"]

def add_trash(code):
    return code.rstrip() + "\\n" + "\\n".join(random.choice(TRASH) for _ in range(random.randint(1,4))) + "\\n"

def submit(path):
    p = Path(path.strip().strip('"').strip("'"))
    if not p.exists():
        print(f"Файл не найден: {p}")
        return
    code = p.read_text(encoding="utf-8") + add_trash(p.read_text(encoding="utf-8"))

    s = requests.Session()
    s.cookies.update(COOKIES)
    files = {"file": ("sol.py", code.encode(), "text/x-python")}
    data = {"lang_id": LANG_ID, "course_id": COURSE_ID}

    try:
        r = s.post(SUBMIT_URL, data=data, files=files, timeout=30)
        if "run_id" in r.text:
            print(f"[{time.strftime('%H:%M:%S')}] Отправлено! run_id = {r.json()['data']['run_id']}")
        else:
            print("Ошибка:", r.text[:200])
    except Exception as e:
        print("Ошибка:", e)

if __name__ == "__main__":
    path = input("\\nПеретащи свой .py файл сюда → ").strip().strip('"').strip("'")
    print(f"\\nАвтосабмит на задачу {PROBLEM_ID} запущен!")
    print("Отправка каждые 3 минуты (Ctrl+C — остановить)\\n")
    while True:
        submit(path)
        for i in range(180, 0, -1):
            print(f"\\rСледующая через {i} сек... ", end="", flush=True)
            time.sleep(1)
        print()
`;
}
