chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.action === "generate") {
    chrome.tabs.query({ active: true, currentWindow: true }, tabs => {
      const url = tabs[0].url;
      if (!url.includes("informatics.msk.ru")) return;

      chrome.cookies.getAll({ url: "https://informatics.msk.ru" }, cookies => {
        const c = {};
        cookies.forEach(k => c[k.name] = k.value);

        chrome.tabs.executeScript(tabs[0].id, {
          code: `JSON.stringify([
            document.querySelector('.userbutton .usertext')?.textContent.trim() || "Аноним",
            document.querySelector('h2')?.textContent.trim() || "Задача",
            new URLSearchParams(location.search).get('chapterid') || "0"
          ])`
        }, result => {
          if (result && result[0]) {
            const [name, title, chapterid] = JSON.parse(result[0]);
            sendResponse({ name, title, chapterid, cookies: c });
          }
        });
      });
    });
    return true; // асинхронный ответ
  }
});
