document.addEventListener("DOMContentLoaded", () => {
  const params = new URLSearchParams(location.search);
  const user = params.get("user") || "Неизвестно";
  const task = params.get("task") || "Задача";
  const id = params.get("id") || "0";
  const cookiesJson = params.get("cookies") || "{}";

  let cookies;
  try { cookies = JSON.parse(decodeURIComponent(cookiesJson)); }
  catch (e) { cookies = {}; }

  document.getElementById("user").textContent = user;
  document.getElementById("task").textContent = `${id} — ${task}`;

  const codeEl = document.getElementById("code");
  const slider = document.getElementById("intervalSlider");
  const valueEl = document.getElementById("intervalValue");

  let interval = 180;

  function formatTime(sec) {
    const m = Math.floor(sec / 60);
    const s = sec % 60;
    return `${m} мин ${s.toString().padStart(2, '0')} сек`;
  }

  function generateScript(interval) {
    return `# Автоматически сгенерировано расширением "Informatics Auto-Submit Pro"
# Задача №${id}: ${task}
# Интервал: каждые ${formatTime(interval)}

import requests, time, random
from pathlib import Path

COOKIES = {
    "cf_clearance": "${cookies.cf_clearance || ""}",
    "MoodleSession": "${cookies.MoodleSession || ""}",
    "MOODLEID1_": "${cookies.MOODLEID1_ || ""}"
}

PROBLEM_ID = ${id}
SUBMIT_URL = f"https://informatics.msk.ru/py/problem/{PROBLEM_ID}/submit"
TRASH = ["# kek", "# lol", "# spam", "# auto", "# pls_accept", "# generated", "# cheburek", "# 100%"]

def add_trash(code):
    return code.rstrip() + "\\n" + "\\n".join(random.choice(TRASH) for _ in range(random.randint(1,4))) + "\\n"

def submit(path):
    p = Path(path.strip().strip('"').strip("'"))
    if not p.exists():
        print(f"Файл не найден: {p}")
        return
    code = p.read_text(encoding="utf-8")
    code = add_trash(code)

    s = requests.Session()
    s.cookies.update(COOKIES)
    files = {"file": ("sol.py", code.encode(), "text/x-python")}
    data = {"lang_id": 27, "course_id": 6325}

    try:
        r = s.post(SUBMIT_URL, data=data, files=files, timeout=30)
        if "run_id" in r.text:
            print(f"[{time.strftime('%H:%M:%S')}] Отправлено! run_id = {r.json()['data']['run_id']}")
        else:
            print("Ошибка:", r.text[:200])
    except Exception as e:
        print("Ошибка:", e)

if __name__ == "__main__":
    path = input("\\nПеретащи свой .py файл сюда: ").strip().strip('"').strip("'")
    if not path:
        print("Путь пустой — выход.")
        exit()

    print(f"\\nАвтосабмит на задачу {PROBLEM_ID} запущен!")
    print(f"Отправка каждые ${formatTime(interval)} (Ctrl+C — стоп)\\n")

    while True:
        submit(path)
        for i in range(${interval}, 0, -1):
            mins = i // 60
            secs = i % 60
            print(f"\\rСледующая: {mins:02d}:{secs:02d} ", end="", flush=True)
            time.sleep(1)
        print()
`;
  }

  function update() {
    interval = parseInt(slider.value);
    valueEl.textContent = formatTime(interval);
    codeEl.textContent = generateScript(interval);
    if (typeof Prism !== "undefined") {
      Prism.highlightElement(codeEl);
    }
  }

  slider.addEventListener("input", update);

  document.getElementById("downloadBtn").onclick = () => {
    const blob = new Blob([generateScript(interval)], { type: "text/x-python" });
    const url = URL.createObjectURL(blob);
    chrome.downloads.download({
      url: url,
      filename: `autosubmit_${id}_every_${interval}s.py`,
      saveAs: true
    });
    setTimeout(() => URL.revokeObjectURL(url), 5000);
  };

  document.getElementById("copyBtn").onclick = () => {
    navigator.clipboard.writeText(generateScript(interval)).then(() => {
      const b = document.getElementById("copyBtn");
      b.textContent = "Скопировано!";
      b.classList.add("copied");
      setTimeout(() => {
        b.textContent = "Скопировать в буфер";
        b.classList.remove("copied");
      }, 2000);
    });
  };

  // Первая загрузка
  update();
});
