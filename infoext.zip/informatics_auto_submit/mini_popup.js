document.getElementById("open").addEventListener("click", () => {
  // 1. Получаем активную вкладку
  chrome.tabs.query({ active: true, currentWindow: true }, tabs => {
    const tab = tabs[0];
    const url = tab.url || "";

    if (!url.includes("informatics.msk.ru")) {
      alert("Откройте задачу на informatics.msk.ru");
      return;
    }

    // 2. Собираем данные через background
    chrome.runtime.sendMessage({ action: "generate" }, response => {
      if (!response) {
        alert("Ошибка получения данных");
        return;
      }

      // 3. Кодируем данные в URL (безопасно и коротко)
      const params = new URLSearchParams({
        user: response.name,
        task: response.title,
        id: response.chapterid,
        cookies: JSON.stringify(response.cookies)
      });

      // 4. Открываем новую вкладку с готовыми данными
      chrome.tabs.create({
        url: chrome.runtime.getURL("full_editor.html") + "?" + params.toString()
      });
    });
  });
});
